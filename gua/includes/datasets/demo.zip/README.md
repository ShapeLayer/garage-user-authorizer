# Training set for FaceNet

 * use guid for labeling
  * Author
    * `dbdfb375-c57a-4086-a0bb-906ffa393973` - Jonghyeon Park(@ShapeLayer)
  * Lovelyz
    * `f13a6c78-7892-441e-a107-00deb56d026c` - babysoul
    * `616ca517-f619-4763-a2e0-faedec973550` - jiae
    * `2c18751e-711f-4274-bf57-56daecead826` - jin
    * `b2b40471-de40-443a-8c2d-151a74ca74a9` - jisoo
    * `be1a8f54-4706-4575-959c-4eb5e4b57327` - kei
    * `b7a7400a-6c44-43c0-be55-bbaa14a58011` - mijoo
    * `920f6564-2a85-4fcb-ae17-849aca5b9ebe` - sujeong
    * `7f95e8d7-93af-4171-a1f2-9fd8965deac8` - yein
  * [5 Celebrity Faces Dataset](https://www.kaggle.com/datasets/dansbecker/5-celebrity-faces-dataset)
    * `47f7bbd9-9620-4e2e-a89e-04c6d32bb33b` - ben afflek
    * `bd226c75-93ff-4804-a4b7-4f267675f81a` - elton john
    * `02b79bfa-7904-4185-92b2-9eb2668208a6` - jerry seinfeld
    * `71dba595-e042-42ac-94df-e728e88c61ff` - madonna
    * `b9002aef-1149-4a02-94d7-4f577e07b72a` - mindy_kaling
